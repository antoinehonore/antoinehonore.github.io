# kthpresentation
Beamer theme definition to create slides using LaTeX+Beamer, imitating the KTH Powerpoint graphic profile from 2023.

Check `examplepresentation.tex` for an example presentation and some documentation.

